Para compilar el tetris ejecutar el make, con solo poner make en la terminal esta bien, este genera un ejecutable que 
se llama tetris, que es el que depues se ejecuta con el ./tetris en la terminal, el tetris no esta en su version final 
y toca acabarle unas cosas, para jugar estan las funciones: rotar, moverder,noverizq,bajar y ya las demas se 
encargan de la logica y procedimientos.

Edgar Manuel Amezquita
3cer semestre
Ing. Sistemas y Computacion

